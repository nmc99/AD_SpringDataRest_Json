package com.campusfp.springdataresttest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringdatarestTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
